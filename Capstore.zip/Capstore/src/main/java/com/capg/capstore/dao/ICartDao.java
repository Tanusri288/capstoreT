package com.capg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.capstore.beans.Cart;
import com.capg.capstore.beans.CartProduct;

@Repository("cartDao")
@Transactional
public interface ICartDao extends JpaRepository<Cart, Integer>{

	@Query("from Cart  where customer_customer_id=:custId")
	public List<Cart> findCartByCustomerIdCustomerId(@Param("custId") Integer custId);

	@Query("from Cart where customer_customer_id=:custId")
	public Cart findByCustomer(@Param("custId") Integer custId);

	

}
