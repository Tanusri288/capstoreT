package com.capg.capstore.exceptions;

public class CartException {

}
