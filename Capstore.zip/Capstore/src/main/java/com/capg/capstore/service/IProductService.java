package com.capg.capstore.service;

import java.util.List;

import com.capg.capstore.beans.Product;

public interface IProductService {

	List<Product> getAllProducts();

	Product getProductById(int productId);

	Product addProduct(Product product);

	Product updateProduct(Product product);

}
