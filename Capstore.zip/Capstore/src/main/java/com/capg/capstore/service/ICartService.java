package com.capg.capstore.service;

import java.util.List;

import com.capg.capstore.beans.Cart;
//import com.capg.capstore.model.CartProduct;
import com.capg.capstore.beans.CartProduct;

public interface ICartService {

//	Cart addProductToCart(CartProduct cartProduct, String customerEmailId);

//	Cart deleteProductFromCart(String customerEmailId, Integer productId);
	public Cart deleteProductFromCart(int customerId, int productId) ;
	
	public Cart getCartProducts(int customerId) ;
	
	public Cart updateCartProductQuantity(CartProduct cartProduct, int customerId);

	public int getCount();

//	public double calculateTotalCartAmount(Cart cart);

	Cart addProductToCart(CartProduct cartProduct, int customerId);

}
