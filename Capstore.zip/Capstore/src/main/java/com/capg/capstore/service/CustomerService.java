package com.capg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.capstore.beans.Customer;
import com.capg.capstore.dao.ICustomerDao;



@Service
public class CustomerService implements ICustomerService {
	

    
    @Autowired
    ICustomerDao repository;


    @Override
    public void addCustomer(Customer customer) {
        repository.save(customer);
    }


    @Override
    public Customer getById(int id) {
        return repository.findById(id).orElse(null);
    }


}





