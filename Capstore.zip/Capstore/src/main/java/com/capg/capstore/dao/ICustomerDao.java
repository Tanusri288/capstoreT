package com.capg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.capstore.beans.Customer;

public interface ICustomerDao extends JpaRepository<Customer, Integer> {

}
