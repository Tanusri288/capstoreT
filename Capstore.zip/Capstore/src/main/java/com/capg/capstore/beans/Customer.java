package com.capg.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="capgcustomer")
public class Customer {
   
    @Id
    @SequenceGenerator(name="seq",sequenceName="customer_sequence")
    @GeneratedValue(generator="seq")
    private int customerId;
    private String customerName;
    private long customerMobile;
    private String customerEmail;
    private String customerPassword;
    private String customerHistory;
    private String customerCartId;
    private int customerWallet;
   
   
    @Override
    public String toString() {
        return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerMobile="
                + customerMobile + ", customerEmail=" + customerEmail + ", customerPassword=" + customerPassword
                + ", customerHistory=" + customerHistory + ", customerCartId=" + customerCartId + ", customerWallet="
                + customerWallet + "]";
    }
   
   
    public int getCustomerId() {
        return customerId;
    }
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public long getCustomerMobile() {
        return customerMobile;
    }
    public void setCustomerMobile(long customerMobile) {
        this.customerMobile = customerMobile;
    }
    public String getCustomerEmail() {
        return customerEmail;
    }
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }
    public String getCustomerPassword() {
        return customerPassword;
    }
    public void setCustomerPassword(String customerPassword) {
        this.customerPassword = customerPassword;
    }
    public String getCustomerHistory() {
        return customerHistory;
    }
    public void setCustomerHistory(String customerHistory) {
        this.customerHistory = customerHistory;
    }
    public String getCustomerCartId() {
        return customerCartId;
    }
    public void setCustomerCartId(String customerCartId) {
        this.customerCartId = customerCartId;
    }
    public int getCustomerWallet() {
        return customerWallet;
    }
    public void setCustomerWallet(int customerWallet) {
        this.customerWallet = customerWallet;
    }
   
}
