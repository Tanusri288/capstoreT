package com.capg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.capstore.beans.Product;
import com.capg.capstore.dao.IProductDao;

@Service
public class ProductService implements IProductService {

	@Autowired
	IProductDao productDao;

	@Override
	public List<Product> getAllProducts() {
		return productDao.findAll();
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return productDao.findById(productId).orElse(null);
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productDao.save(product);
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return productDao.save(product);
	}

}
