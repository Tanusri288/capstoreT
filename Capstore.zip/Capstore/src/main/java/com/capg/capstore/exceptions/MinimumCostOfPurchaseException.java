package com.capg.capstore.exceptions;

public class MinimumCostOfPurchaseException extends Exception {
	public MinimumCostOfPurchaseException() {
		super();
	}

	public MinimumCostOfPurchaseException(String msg) {
		super(msg);
	}

}
