package com.capg.capstore.service;

import com.capg.capstore.beans.Customer;

public interface ICustomerService {
	public void addCustomer(Customer customer) ;
	 public Customer getById(int id) ;
}
