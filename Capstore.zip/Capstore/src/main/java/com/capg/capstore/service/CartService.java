package com.capg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.capstore.beans.Cart;
import com.capg.capstore.beans.CartProduct;
import com.capg.capstore.beans.Customer;
import com.capg.capstore.dao.ICartDao;
import com.capg.capstore.dao.ICartProductDao;
@Service("cartService")
public class CartService implements ICartService {

	@Autowired
	ICartDao cartDao;
	
	@Autowired
	ICartProductDao cartProductDao;
	
	@Autowired
	ICustomerService customerService;
	
	@Autowired
	IProductService productService;
	
	

	@Override
	public Cart addProductToCart(CartProduct cartProduct, int customerId) {
		
		Customer customer=customerService.getById(customerId);

		
		System.out.println("1"+cartProduct);

		System.out.println(customer);
		

		Cart cart=cartDao.findByCustomer(customer.getCustomerId());
		
		if(cart==null)
		{
			
			cart=new Cart();
			
			cart.setCustomer(customer);
			cartProductDao.save(cartProduct);
			
			cart.getCartProducts().add(cartProduct);
			cart.setMinimumAmount(100);
			System.out.println("cart"+cart);
			cartDao.save(cart);
		}
		else
		{
			boolean flag=false;
			List<CartProduct> cartProducts=cart.getCartProducts();
			System.out.println("2"+cartProducts);
			for(CartProduct cartProduct1:cartProducts)
			{
				System.out.println("3"+cartProduct1);
				
				//if the product already exists
				
				if(cartProduct1.getProduct().getProductId()==(cartProduct.getProduct().getProductId()))
				{
					flag=true;
					return cart;
				}
			}
			if(!flag) {
				
			/*save the product in table if it new product is added
			cartProductDao.save(cartProduct);
			
			add the product to cart table*/
				
			cart.getCartProducts().add(cartProduct);
			
			cartDao.save(cart);}
			
		}
		return cart;
	}
	
	@Override
	public Cart deleteProductFromCart(int customerId, int productId) {
		
		Customer customer=customerService.getById(customerId);
		Cart cart=cartDao.findByCustomer(customer.getCustomerId());
		
		if(cart==null)
			return null;
		else
		{
			
			CartProduct cartProduct=cartProductDao.findByProduct(productId,customer.getCustomerId());
			
			//cart.getCartProducts().remove(cartProduct);
			cartProductDao.delete(cartProduct);
			cart=cartDao.findByCustomer(customer.getCustomerId());
			
			return cart;
		}
		
	}
	
	@Override
	public Cart getCartProducts(int customerId) {
		Customer customer=customerService.getById(customerId);
		
		Cart cart=cartDao.findByCustomer(customer.getCustomerId());
		return cart;
	}

	@Override
	public Cart updateCartProductQuantity(CartProduct cartProduct, int customerId) {
		
		//Cart cart=cartDao.findByCustomer(customerId);
		Customer customer=customerService.getById(customerId);
		
		int quantity=cartProduct.getQuantity();
		
		cartProductDao.updateQuantity(quantity,cartProduct.getProduct().getProductId(),customer.getCustomerId());
		
		 Cart cart=cartDao.findByCustomer(customer.getCustomerId());
		
		return cart;
	}

	/*@Override
	public double calculateTotalCartAmount(Cart cart) {
		
		if(cart == null) {
			return 0;
		}
		
		double totalAmount=0;
		
		List<CartProduct> cartProducts = cart.getCartProducts();
		
		for(CartProduct cartProduct:cartProducts) {
			
			double price = productService.getDiscountedPrice(cartProduct.getProduct());
			double quantity = (double)cartProduct.getQuantity();
			
			totalAmount += price*quantity;
		}
		
		return totalAmount;
	}*/
	
	@Override
	public int getCount() {
		return cartProductDao.getCount();
	}



}