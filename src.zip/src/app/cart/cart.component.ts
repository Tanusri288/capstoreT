import { Component, OnInit } from '@angular/core';
import { Cart } from '../Cart'
import { Router } from '@angular/router';
import { CapstoreService } from '../capstore.service';
import { CartProduct } from '../CartProduct';

@Component({
  selector: 'app-cart',
  templateUrl: './cartlist.component.html',
  styleUrls: ['./cartlist.component.css']
})
export class CartComponent implements OnInit {

  router: Router;
 
  constructor(private service:CapstoreService, router: Router) {
    this.router = router;
   }

  cart:Cart[];
  cartProduct:CartProduct[];
  
  ngOnInit() {
    this.service.getCartProducts().subscribe(data => {
      this.cart = data;
      console.log(this.cart);
      });
  }

deleteFromCart(cartId) {
  if (confirm("Are you Sure to REMOVE??")) {
  this.service.deleteFromCart(cartId).subscribe(data => {
  this.cart = data;
  });
  }
  }

addToCart(cartId){
  this.service.addToCart(cartId).subscribe(data =>{this.cart=data;
  });
}



  
}
