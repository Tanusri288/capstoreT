import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from './Cart';
import { HttpClient } from '@angular/common/http';
import { Product } from './Product';

@Injectable({
  providedIn: 'root'
})
export class CapstoreService {

  product: Product[]=[];

  constructor(private http: HttpClient) { }

  getCartProducts(): Observable<Cart[]> {
    console.log(this.http.get<Cart[]>("http://localhost:8089/ecommerce/185692/getCartList/CUST_00001"));
    return this.http.get<Cart[]>("http://localhost:8089/ecommerce/185692/getCartList/CUST_00001");
  }

  deleteFromCart(cartId): Observable<any> {
    return this.http.delete<Cart[]>("http://localhost:8089/ecommerce/185715/deleteProduct/" + cartId);
  }
 
  
  addToCart(data:any) {
   this.product.push(data);
   return this.http.post<any>("http://localhost:8089/ecommerce/addtocartlist/CUST_00001", this.product);
  }

  getcart():Product[]{
    return this.product;
  }
}
