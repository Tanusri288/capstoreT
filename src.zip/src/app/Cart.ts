import{CartProduct} from './CartProduct';
import{Customer} from './Customer';
export class Cart{
    cartId:number;
	cartProduct:CartProduct;
	customer:Customer;
	quantity:number;
}