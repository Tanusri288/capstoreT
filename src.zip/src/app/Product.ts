export class Product {
	// productAvailability:boolean;
	// productBrand:string;
	// productCategory:string;
	// productDiscount:number;
	// productFeedback:string;
	productId:number;
	// productImage:string;
	productName:string;
	productPrice:number;
	// productQuantity:number;
	// productRating:number;
	// productType:string;
	// merchantId:number;
	constructor(productId:number,productName:string,productPrice:number){
		this.productName=productName;
		this.productPrice=productPrice;
		this.productId=productId
	}
	
}



