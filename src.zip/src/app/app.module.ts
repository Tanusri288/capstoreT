import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BagComponent } from './bag/bag.component';
import { BagPageComponent } from './bag-page/bag-page.component';

@NgModule({
  declarations: [
    AppComponent,
    BagComponent,
    BagPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
