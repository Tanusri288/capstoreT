// import{Product} from './Product';
export class CartProduct{
    // product:Product;
    productId: number;
    productName: string;
    quatity: number;
    price:number;
    // constructor(productId:number,productName:string,quatity: number,price: number){
    //     this.productName=productName;
    //     this.productId=productId;
    //     this.quatity=quatity;
    //     this.price=price;
        
    // }
}