export class Customer{
    customerId: number;
    constructor(customerId: number){
        this.customerId = customerId;
    }
}