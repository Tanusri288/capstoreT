package com.capg.capstore_cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoreCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoreCartApplication.class, args);
	}

}
